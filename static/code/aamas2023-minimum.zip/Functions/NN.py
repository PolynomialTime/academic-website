import torch
from torch import nn
from torch.nn.functional import leaky_relu
import numpy as np
 
class QNet(nn.Module):
    def __init__(self, state_shape, n_agents, act_size = 1) -> None:
        super().__init__()
        self.LReLU = nn.LeakyReLU(0.01)
        self.fc1 = nn.Linear(state_shape + n_agents*act_size, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64,n_agents)
        self.reset_param()
        self.loss_func = nn.MSELoss()
    def reset_param(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight.data, gain=nn.init.calculate_gain('leaky_relu'))
                
    def forward(self, state_act):
        input_tensor = torch.tensor(state_act, dtype=torch.float32)
        #input_cat = torch.cat([state_input, action_input], dim=0)
        x1 = self.fc1(input_tensor)
        x1 = self.LReLU(x1)
        x2 = self.fc2(x1)
        x2 = self.LReLU(x2)
        x3 = self.fc3(x2)
        out = x3
        return out

        
class LambdaRiskConstraintNet(nn.Module):
    def __init__(self, state_shape) -> None:
        super().__init__()
        self.LReLU = nn.LeakyReLU(0.01)
        self.fc1 = nn.Linear(state_shape, 32)
        self.fc2 = nn.Linear(32, 16)
        self.fc3 = nn.Linear(16,1)
        self.reset_param()
        self.loss_func = nn.MSELoss()
    def reset_param(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight.data, gain=nn.init.calculate_gain('leaky_relu'))
                
    def forward(self, state):
        input_tensor = torch.tensor(state, dtype=torch.float32)
         
        #input_cat = torch.cat([state_input, action_input], dim=0)
        x1 = self.fc1(input_tensor)
        x1 = self.LReLU(x1)
        x2 = self.fc2(x1)
        x2 = self.LReLU(x2)
        x3 = self.fc3(x2)
        out = torch.relu(x3)+1e-4
        return out


class OMNet(nn.Module):
    def __init__(self, state_shape, n_agents, act_size = 1) -> None:
        super().__init__()
        self.LReLU = nn.LeakyReLU(0.01)
        self.fc1 = nn.Linear(state_shape + n_agents*act_size, 64)
        self.fc2 = nn.Linear(64,32)
        self.fc3 = nn.Linear(32,1)
        self.reset_param()
        self.loss_func = nn.MSELoss()
    def reset_param(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight.data, gain=nn.init.calculate_gain('leaky_relu'))
                
    def forward(self, state_act):
        input_tensor = torch.tensor(state_act, dtype=torch.float32)
         
        #input_cat = torch.cat([state_input, action_input], dim=0)
        x1 = self.fc1(input_tensor)
        x1 = self.LReLU(x1)
        x2 = self.fc2(x1)
        x2 = self.LReLU(x2)
        x3 = self.fc3(x2)
        out = torch.relu(x3)+1e-4
        return out


class CentralOMNet(nn.Module):
    def __init__(self, state_shape, state_num, jact_num, n_agents, act_size = 1) -> None:
        super().__init__()
        self.LReLU = nn.LeakyReLU(0.01)
        self.fc1 = nn.Linear(state_num*jact_num*( state_shape+ n_agents*act_size), 64)
        self.fc2 = nn.Linear(64,32)
        self.fc3 = nn.Linear(32,state_num*jact_num)
        self.reset_param()
        self.loss_func = nn.MSELoss()
    def reset_param(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight.data, gain=nn.init.calculate_gain('leaky_relu'))
                
    def forward(self, state_act):
        input_tensor = torch.tensor(state_act, dtype=torch.float32)
         
        #input_cat = torch.cat([state_input, action_input], dim=0)
        x1 = self.fc1(input_tensor)
        x1 = self.LReLU(x1)
        x2 = self.fc2(x1)
        x2 = self.LReLU(x2)
        x3 = self.fc3(x2)
        out = torch.relu(x3)+1e-4
        out = out / torch.sum(out) * 99.999
        return out

class LambdaNet(nn.Module):
    def __init__(self, state_shape, act_size=1) -> None:
        super().__init__()
        self.LReLU = nn.LeakyReLU(0.01)
        self.fc1 = nn.Linear(state_shape+2*act_size, 128)  # state, a_i, a_i'
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64,1)
        self.reset_param()
        self.loss_func = nn.MSELoss()
    def reset_param(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight.data, gain=nn.init.calculate_gain('leaky_relu'))
                
    def forward(self, state_ai_aialter):
        input_tensor = torch.tensor(np.array(state_ai_aialter), dtype=torch.float32)
        #input_cat = torch.cat([state_input, action_input], dim=0)
        x1 = self.fc1(input_tensor)
        x1 = self.LReLU(x1)
        x2 = self.fc2(x1)
        x2 = self.LReLU(x2)
        x3 = self.fc3(x2)
        out = self.LReLU(x3)
        return out

class MuNet(nn.Module):
    def __init__(self, state_shape) -> None:
        super().__init__()
        self.LReLU = nn.LeakyReLU(0.01)
        self.fc1 = nn.Linear(state_shape, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64,1)
        self.reset_param()
        self.loss_func = nn.MSELoss()
    def reset_param(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight.data, gain=nn.init.calculate_gain('leaky_relu'))
                
    def forward(self, state_input):
        input_tensor = torch.tensor(np.array(state_input), dtype=torch.float32)
         
        #input_cat = torch.cat([state_input, action_input], dim=0)
        x1 = self.fc1(input_tensor)
        x1 = self.LReLU(x1)
        x2 = self.fc2(x1)
        x2 = self.LReLU(x2)
        x3 = self.fc3(x2)
        x3 = self.LReLU(x3)
        out = x3
        return out
