def cal_qval(occupancy_measure, qtables, environment):
    risk_ids = environment.bad_states
    occupancy_measure = occupancy_measure.reshape(environment.possible_states,
                                                  environment.joint_act_nums)
    risk_oms = occupancy_measure[list(risk_ids)]
    om_sums = np.sum(risk_oms,1).reshape(-1,1)
    om_policy = risk_oms / om_sums
    result = 0
    #qtables = [qtable1,qtable2]
    for qtable in qtables:
        risk_qt = qtable[list(risk_ids)]
        q_mul_pi = np.multiply(om_policy, risk_qt)
        sum_q = np.sum(q_mul_pi)
        result = result + sum_q
    return result

def cal_abs_qval(occupancy_measure, qtables, environment):
    risk_ids = environment.bad_states
    occupancy_measure = occupancy_measure.reshape(environment.possible_states,
                                                  environment.joint_act_nums)
    risk_oms = occupancy_measure[list(risk_ids)]
    om_sums = np.sum(risk_oms,1).reshape(-1,1)
    om_policy = risk_oms / om_sums
    result = 0
    #qtables = [qtable1,qtable2]
    for qtable in qtables:
        risk_qt = np.abs(qtable[list(risk_ids)])
        q_mul_pi = np.multiply(om_policy, risk_qt)
        sum_q = np.sum(q_mul_pi)
        result = result + sum_q
    return result