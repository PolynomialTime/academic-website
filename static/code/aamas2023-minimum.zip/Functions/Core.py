from math import gamma
import random
import numpy as np
from itertools import product
import copy


class QTable(object):
    def __init__(self, state_num, action_num, agent_num, gamma=0.99, alpha=0.3) -> None:
        self.qt = np.random.random((state_num, np.power(action_num, agent_num)))
        #self.qt = np.zeros((state_num, np.power(action_num, agent_num)))
        self.gamma = gamma
        self.alpha = alpha
        pass

    def get_q(self, state, action):
        return self.qt[state][action]

    def get_q_row(self, state):
        return self.qt[state]

    def update_q(self, reward,state_id,action_id,s_new_id,pi_a_snew):
        if self.alpha > 0.001:
            self.alpha -= 0.0001
        V_snew = np.sum(pi_a_snew * self.qt[s_new_id])
        td_err = reward - self.qt[state_id][action_id] + self.gamma*V_snew
        self.qt[state_id][action_id] += td_err*self.alpha
        return 1


    def update_q_done(self, reward, s, a):
        
        self.qt[s, a] = reward
        return 1


class JointPolicy(object):
    """
    This is the joint policy version, which means agents do not act individually
    """
    def __init__(self, env) -> None:
        super().__init__()
        self.n_agents = env.num_agents
        self.all_states = env.get_all_states()
        self.numS = env.possible_states
        self.numA = env.joint_act_nums
        self.env = env
        self.policy = np.full(self.numA*self.numS, 1/(self.numA)).reshape(self.numS, self.numA)
        self.gamma = 0.9
        self.all_nn_inputs = self.init_nn_inputs()
    def derive_pi(self, occupancy_measure):
        occupancy_measure = occupancy_measure.reshape(self.numS,self.numA)
        for i in range(len(occupancy_measure)):
            row = occupancy_measure[i]
            total_om = np.sum(row)
            pi_current_s = np.divide(row, total_om)
            self.policy[i] = pi_current_s
            if sum(self.policy[i]) != 1:
                print(sum(self.policy[i]))
        return self.policy
    def init_nn_inputs(self):
        l = []
        for state in self.all_states:
            obs = self.env.state_to_obs(state)
            for act in self.env.all_jacts:
                arr_act = np.array(act).reshape(-1)
                nn_input = np.concatenate((obs,arr_act))
                l.append(nn_input)
        return l
    def derive_pi_nn(self, om_net):
        probs = []
        for nn_input in self.all_nn_inputs:
            prob = om_net.forward(nn_input).detach().numpy()
            probs.append(prob)
        probs = np.array(probs).reshape(self.numS,self.numA)
        probs = ((probs.T)/probs.sum(axis=1)).T
        self.policy = probs
def pick_action(state, policy):
    state = int(state)
    act_probs = policy.policy[state]
    act_probs /= act_probs.sum()
    act = np.random.choice(a=np.arange(len(act_probs)), size=1, p=act_probs)
    return int(act[0])

def TD_update_q(qt_tables, policy, env, max_iter):
    """
    Update q-tables by td-error
    """
    for m in range(10):
        s = env.reset()
        for n in range(int(max_iter/10)):
            old_tables = [copy.deepcopy(qt_tables[i]) for i in range(env.num_agents)]
            state_id = env.vec_to_ind(s)
            action_id = pick_action(state_id, policy)
            action = env.ind_to_act(action_id)
            s_new, r, done, info = env.step(action)
            #if (not done) and (s_new is not None):
            s_new_id = env.vec_to_ind(s_new)
            pi_a_snew = policy.policy[s_new_id]
            for i in range(env.num_agents):
                qt_tables[i].update_q(r[i], state_id,action_id,s_new_id,pi_a_snew)
            s = s_new
    return 1


if __name__ == '__main__':
    min_state = np.array([-2, -2, -2, -2, -2])
    state_len = 5
    all_cases = [0 for _ in range(3125)]
    for q in range(-2, 3):
        for w in range(-2, 3):
            for e in range(-2, 3):
                for r in range(-2, 3):
                    for t in range(-2, 3):
                        state = [q, w, e, r, t]
                        diff = state - min_state
                        to_id = 0
                        for i in range(state_len):
                            to_id += np.power(5, 4 - i) * diff[i]
                            all_cases[to_id] = 1
    if sum(all_cases) == 3125:
        print("correct")
    if sum(np.array(all_cases) == 0) > 0:
        print("false")